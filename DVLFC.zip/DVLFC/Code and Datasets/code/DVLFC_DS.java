package ceka.DVLFC;

import weka.classifiers.Classifier;
import weka.classifiers.bayes.NaiveBayes;
import weka.core.Attribute;
import weka.core.FastVector;
import weka.core.Utils;

import java.util.ArrayList;

import ceka.consensus.ds.GalDawidSkene;
import ceka.core.Dataset;
import ceka.core.Example;
import ceka.core.Label;

public class DVLFC_DS {

	public static final String NAME = "DVLFC_DS";
	
	// worker modeling threshold theta
	double theta = 0.10;
	
	// worker modeling list
	public static ArrayList<Integer> workerModelingList;
	
	// worker modeling classifier
	public static Classifier[] workerModelingClassifier;

	
	public void doInference(Dataset dataset) throws Exception {
		
		// Module 1: Worker Modeling
		
		// get worker number R
		int R = dataset.getWorkerSize();
		workerModelingClassifier = new NaiveBayes[R];
		
		//for each worker W_{r}, build a model M_{r}
		for (int r = 0; r < R; r++) {
			
			// get worker id
			String workerId = dataset.getWorkerByIndex(r).getId();
			// get worker label size
			int workerLabelSize = dataset.getWorkerByIndex(r).getMultipleNoisyLabelSet(0).getLabelSetSize();
			// get instance number I
			int I = dataset.getExampleSize();
			
			// if worker label size >= modeling threshold
			if (workerLabelSize >= theta * I) {
				// get their labeled data
				Dataset labeledData = new Dataset(dataset);
				// clear the labeled data set
				labeledData.delete();
				// get their unlabeled data
				Dataset unlabeledData = new Dataset(dataset);
				// clear the unlabeled data set
				unlabeledData.delete();		

				for (int i = 0; i < I; i++) {
					// get an example
					Example example = dataset.getExampleByIndex(i);
					// if is labeled data
					if (example.getNoisyLabelByWorkerId(workerId) != null) {
						// get worker's label
						int value = example.getNoisyLabelByWorkerId(workerId).getValue();
						// take the worker label as class label
						example.setTrainingLabel(value);
						// add to the labeled data set
						labeledData.addExample(example);
					}
					// if is unlabeled data
					else {
						unlabeledData.addExample(example);
					}
				}

				// Module 1: worker modeling
				// model the rth worker on their labeled data
				workerModelingClassifier[r] = new NaiveBayes();
				workerModelingClassifier[r].buildClassifier(labeledData);
				
				// Module 2: label augmentation
				// use the built model to predict pseudo labels for their unlabeled data
				int noLabelSize = unlabeledData.getExampleSize();
				for (int j = 0; j < noLabelSize; j++) {
					Example noLabel_example = unlabeledData.getExampleByIndex(j);
					int predictedClassLabel = Utils.maxIndex(workerModelingClassifier[r].distributionForInstance(noLabel_example));
					Label tmpLabel = new Label(null, String.valueOf(predictedClassLabel), String.valueOf(noLabel_example.getId()), workerId);
					// add the predicted pseudo label into the noisy labels for the unlabeled data
					dataset.getExampleById(noLabel_example.getId()).addNoisyLabel(tmpLabel);
					// add the predicted pseudo label into the noisy labels for the worker
					dataset.getWorkerById(workerId).addNoisyLabel(tmpLabel);
				}
			}
		}

		// Module 3: label integration.
		// Utilize a label integration method to infer their integrated labels
		GalDawidSkene ds = new GalDawidSkene("./data/output/MVL/MVL_DS/");
		ds.doInference(dataset);

		// regard the integrated label for the class label
		dataset.assignIntegeratedLabel2WekaInstanceClassValue();
		
	}
	
	
	/*
	 * generate augmented label view (training phase)
	 */
	public Dataset generateAugmentedLabelView_Train(Dataset dataset) throws Exception {

		Dataset view2_dataset = Dataset.copyDataset(dataset);

		// count the worker number of labeling more than theta
		int workerSize = view2_dataset.getWorkerSize();
		int workerNumCnt = 0;
		ArrayList<String> workerIdList = new ArrayList<String>();
		workerModelingList = new ArrayList<Integer>();
		for (int index = 0; index < workerSize; index++) {
			String workerId = view2_dataset.getWorkerByIndex(index).getId();
			int workerLabelSize = view2_dataset.getWorkerByIndex(index).getMultipleNoisyLabelSet(0).getLabelSetSize();
			if (workerLabelSize >= theta * view2_dataset.getExampleSize()) {
				workerNumCnt++;
				workerIdList.add(workerId);
				workerModelingList.add(index);
			}
		}

		// delete the original attributes
		int attrNum = view2_dataset.numAttributes() - 1;
		for (int i = 0; i < attrNum; i++) {
			view2_dataset.deleteAttributeAt(0);
		}
		
		// add the worker label attributes
		for (int index = 0; index < workerNumCnt; index++) {
			FastVector list = new FastVector(view2_dataset.numClasses());
			for (int j = 0; j < view2_dataset.numClasses(); j++) {
				list.addElement(String.valueOf(j));
			}
			Attribute att = new Attribute("attribute_" + index, list);
			view2_dataset.insertAttributeAt(att, index);
		}

		// construct the augmented label set
		int nowWorkerIndex = -1;
		for (int i = 0; i < workerSize; i++) {
			String workerId = view2_dataset.getWorkerByIndex(i).getId();
			// if the worker contains in the workerIdList (label more than theta)
			if (workerIdList.contains(workerId)) {
				nowWorkerIndex++;
				for (int j = 0; j < view2_dataset.getExampleSize(); j++) {
					Example example = view2_dataset.getExampleByIndex(j);
					if (example.getNoisyLabelByWorkerId(workerId) != null) {
						int value = example.getNoisyLabelByWorkerId(workerId).getValue();
						// add the worker label to the augmented label set
						view2_dataset.instance(j).setValue(nowWorkerIndex, value);
					}
				}
			}
		}

		return view2_dataset;

	}

	/*
	 * generate augmented label view (test phase)
	 */
	public Dataset generateAugmentedLabelView_Test(Dataset dataset, int workerNum) throws Exception {

		Dataset view2_dataset = Dataset.copyDataset(dataset);
		
		// delete the original attributes
		int attrNum = view2_dataset.numAttributes() - 1;
		for (int i = 0; i < attrNum; i++) {
			view2_dataset.deleteAttributeAt(0);
		}
		// add the worker label attributes
		for (int index = 0; index < workerNum; index++) {
			FastVector list = new FastVector(view2_dataset.numClasses());
			for (int j = 0; j < view2_dataset.numClasses(); j++) {
				list.addElement(String.valueOf(j));
			}
			Attribute att = new Attribute("attribute_" + index, list);
			view2_dataset.insertAttributeAt(att, index);
		}
		
		// construct the augmented label set
		for (int i = 0; i < workerNum; i++) {
			for (int j = 0; j < dataset.getExampleSize(); j++) {
				Example example = dataset.getExampleByIndex(j);
				int predictedClassLabel = Utils.maxIndex(workerModelingClassifier[workerModelingList.get(i)].distributionForInstance(example));
				view2_dataset.instance(j).setValue(i, predictedClassLabel);
			}
		}

		return view2_dataset;

	}
	

}
