package ceka.DVLFC;

import java.io.File;
import java.io.FileWriter;
import java.text.DecimalFormat;
import java.util.Random;

import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.bayes.NaiveBayes;
import weka.classifiers.bayes.WANBIA.WANBIA;
import weka.core.Utils;
import ceka.IWMV.IWMV;
import ceka.MNLDP.Iteration;
import ceka.consensus.ds.GalDawidSkene;
import ceka.consensus.gtic.GTIC;
import ceka.converters.FileLoader;
import ceka.core.Dataset;
import ceka.core.Example;
import ceka.utils.PerformanceStatistic;

public class Main {

	private static String dataSetArffDir = "./data/real-world/";

	// arffx
	private static String[] dataSetArddFix = { "leaves", "Income94"};

	private static String runDir = "./data/output/DVLFC/";

	private static int num_data = 2;

	private static int num_Folds = 10;

	private static int num_times = 1;

	private static Classifier m_classifier = new NaiveBayes();

	private static Classifier m_classifier_view1 = new NaiveBayes();

	private static Classifier m_classifier_view2 = new NaiveBayes();

	public static void main(String[] args) throws Exception {

		File testDir = new File(runDir);
		if (!testDir.exists())
			testDir.mkdirs();

		// format data
		DecimalFormat df = new DecimalFormat("#.00");

		for (int data = 0; data < num_data; data++) {

			String fileName = "ModelQuality_" + dataSetArddFix[data] + ".csv";

			File f = new File("./data/output/DVLFC/" + fileName);
			FileWriter fw = new FileWriter(f);

			fw.write("Dataset," + "DS," + "DS_V1," + "DS_V2," + "DS_DVLFC," + "IWMV,"
					+ "IWMV_V1," + "IWMV_V2," + "IWMV_DVLFC," + "GTIC," + "GTIC_V1,"
					+ "GTIC_V2," + "GTIC_DVLFC," + "MNLDP," + "MNLDP_V1," + "MNLDP_V2,"
					+ "MNLDP_DVLFC,");
			fw.write("\r\n");
			
			String fileName2 = "LabelQuality_" + dataSetArddFix[data] + ".csv";
			File f2 = new File("./data/output/DVLFC/" + fileName2);
			FileWriter fw2 = new FileWriter(f2);

			fw2.write("Dataset," + "DS," + "DS_DVLFC," + "IWMV," + "IWMV_DVLFC," + "GTIC," + "GTIC_DVLFC," + "MNLDP," + "MNLDP_DVLFC,");
			fw2.write("\r\n");

			String response = dataSetArffDir + dataSetArddFix[data] + ".response.txt";
			String gold = dataSetArffDir + dataSetArddFix[data] + ".gold.txt";
			String datasetArffPath = dataSetArffDir + dataSetArddFix[data] + ".arffx";
			System.out.print("Dataset = " + dataSetArddFix[data] + " ");
			Dataset dataset = FileLoader.loadFileX(response, gold, datasetArffPath);

			System.out.println("Instance Number = " + dataset.numInstances());
			
			// Model Quality
			double[] classifi_acc_all = new double[16];
			
			// Label Quality
			double[] integra_acc_all = new double[8];

			for (int i = 0; i < num_times; i++) {

				Random rand = new Random();

				// scrambled data set
				dataset.randomize(rand);

				for (int k = 0; k < num_Folds; k++) {
					
					double[] inte_acc = new double[8];

					double[] classifi_acc = new double[16];
					
					PerformanceStatistic reporter = new PerformanceStatistic();

					Dataset train = dataset.trainCV(dataset, num_Folds, k);
					Dataset test = dataset.testCV(dataset, num_Folds, k);

					System.out.println("train instance number =  " + train.numInstances() + " test instance number = " + test.numInstances());

					// DS
					
					Dataset DS_train = Dataset.copyDataset(train);
					GalDawidSkene ds = new GalDawidSkene("./data/output_classiAcc/DVLFC/DS/");
					ds.doInference(DS_train);
					System.out.println("DS:");
					reporter.stat(DS_train);
					inte_acc[0] += reporter.getAccuracy() *100;
					System.out.println("DS accuracy: " + reporter.getAccuracy() + " Roc Area: " + reporter.getAUC()
							+ " Recall: " + reporter.getRecallBinary() + " Precision: " + reporter.getPresicionBinary() + " F1:"
							+ reporter.getF1MeasureBinary());
					DS_train.assignIntegeratedLabel2WekaInstanceClassValue();
					m_classifier.buildClassifier(DS_train);
					Dataset DS_test = Dataset.copyDataset(test);
					Evaluation evaluation = new Evaluation(DS_test);
					evaluation.evaluateModel(m_classifier, DS_test);
					classifi_acc[0] += evaluation.pctCorrect();

					// DS_V1
					
					Dataset MVL_DS_train_view1 = Dataset.copyDataset(train);
					DVLFC_DS mvl_ds = new DVLFC_DS();
					mvl_ds.doInference(MVL_DS_train_view1);
					System.out.println("DS_V1:");
					reporter.stat(MVL_DS_train_view1);
					inte_acc[1] += reporter.getAccuracy() *100;
					System.out.println("DS_V1 accuracy: " + reporter.getAccuracy() + " Roc Area: " + reporter.getAUC()
							+ " Recall: " + reporter.getRecallBinary() + " Precision: " + reporter.getPresicionBinary() + " F1:"
							+ reporter.getF1MeasureBinary());
					m_classifier_view1.buildClassifier(MVL_DS_train_view1);
					Dataset MVL_DS_test_view1 = Dataset.copyDataset(test);
					evaluation = new Evaluation(MVL_DS_test_view1);
					evaluation.evaluateModel(m_classifier_view1, MVL_DS_test_view1);
					classifi_acc[1] += evaluation.pctCorrect();
					System.out.println("Model Quality of DS_V1 = " + evaluation.pctCorrect());

					// DS_V2
					System.out.println("DS_V2:");
					Dataset MVL_DS_train_view2 = Dataset.copyDataset(train);
					DVLFC_DS mvl_ds2 = new DVLFC_DS();
					mvl_ds2.doInference(MVL_DS_train_view2);
					MVL_DS_train_view2 = mvl_ds2.generateAugmentedLabelView_Train(MVL_DS_train_view2);
					m_classifier_view2.buildClassifier(MVL_DS_train_view2);
					Dataset MVL_DS_test_view2 = mvl_ds2.generateAugmentedLabelView_Test(test,
							MVL_DS_train_view2.numAttributes() - 1);
					evaluation = new Evaluation(MVL_DS_test_view2);
					evaluation.evaluateModel(m_classifier_view2, MVL_DS_test_view2);
					classifi_acc[2] += evaluation.pctCorrect();
					System.out.println("Model Quality of DS_V2 = " + evaluation.pctCorrect());
					
					// DS_DVLFC
					System.out.println("DS_DVLFC:");
					double MVL_DS_result12 = 0;
					for (int j = 0; j < test.getExampleSize(); j++) {

						Example MVL_DS_test_view1_example = MVL_DS_test_view1.getExampleByIndex(j);
						Example MVL_DS_test_view2_example = MVL_DS_test_view2.getExampleByIndex(j);
						double[] re_view1 = m_classifier_view1.distributionForInstance(MVL_DS_test_view1_example);
						double[] re_view2 = m_classifier_view2.distributionForInstance(MVL_DS_test_view2_example);
						double[] re_view12 = re_view1;
						for (int yy = 0; yy < re_view1.length; yy++) {
							re_view12[yy] += re_view2[yy];
						}
						if (Utils.maxIndex(re_view12) == MVL_DS_test_view1_example.classValue()) {
							MVL_DS_result12++;
						}

					}
					MVL_DS_result12 = MVL_DS_result12 / test.getExampleSize() * 100;
					classifi_acc[3] += MVL_DS_result12;
					System.out.println("Model Quality of DS_DVLFC = " + MVL_DS_result12);

					// IWMV
					Dataset IWMV_train = Dataset.copyDataset(train);
					IWMV IWMV = new IWMV();
					IWMV.doInference(IWMV_train);
					reporter.stat(IWMV_train);
					inte_acc[2] += reporter.getAccuracy() *100;
					System.out.println("IWMV accuracy: " + reporter.getAccuracy() + " Roc Area: " + reporter.getAUC()
							+ " Recall: " + reporter.getRecallBinary() + " Precision: " + reporter.getPresicionBinary() + " F1:"
							+ reporter.getF1MeasureBinary());
					IWMV_train.assignIntegeratedLabel2WekaInstanceClassValue();
					m_classifier.buildClassifier(IWMV_train);
					Dataset IWMV_test = Dataset.copyDataset(test);
					evaluation = new Evaluation(IWMV_test);
					evaluation.evaluateModel(m_classifier, IWMV_test);
					classifi_acc[4] += evaluation.pctCorrect();
					System.out.println("IWMV=" + evaluation.pctCorrect());

					// IWMV_V1
					Dataset MVL_IWMV_train_view1 = Dataset.copyDataset(train);
					DVLFC_IWMV mvl_iwmv = new DVLFC_IWMV();
					mvl_iwmv.doInference(MVL_IWMV_train_view1);
					reporter.stat(MVL_IWMV_train_view1);
					inte_acc[3] += reporter.getAccuracy() *100;
					System.out.println("IWMV_V1 accuracy: " + reporter.getAccuracy() + " Roc Area: " + reporter.getAUC()
							+ " Recall: " + reporter.getRecallBinary() + " Precision: " + reporter.getPresicionBinary() + " F1:"
							+ reporter.getF1MeasureBinary());
					m_classifier_view1.buildClassifier(MVL_IWMV_train_view1);
					Dataset MVL_IWMV_test_view1 = Dataset.copyDataset(test);
					evaluation = new Evaluation(MVL_IWMV_test_view1);
					evaluation.evaluateModel(m_classifier_view1, MVL_IWMV_test_view1);
					classifi_acc[5] += evaluation.pctCorrect();
					System.out.println("Model Quality of IWMV_V1 = " + evaluation.pctCorrect());

					// IWMV_V2
					Dataset MVL_IWMV_train_view2 = Dataset.copyDataset(train);
					DVLFC_IWMV mvl_iwmv2 = new DVLFC_IWMV();
					mvl_iwmv2.doInference(MVL_IWMV_train_view2);
					MVL_IWMV_train_view2 = mvl_iwmv2.generateAugmentedLabelView_Train(MVL_IWMV_train_view2);
					m_classifier_view2.buildClassifier(MVL_IWMV_train_view2);
					Dataset MVL_IWMV_test_view2 = mvl_iwmv2.generateAugmentedLabelView_Test(test,
							MVL_IWMV_train_view2.numAttributes() - 1);
					evaluation = new Evaluation(MVL_IWMV_test_view2);
					evaluation.evaluateModel(m_classifier_view2, MVL_IWMV_test_view2);
					classifi_acc[6] += evaluation.pctCorrect();
					System.out.println("Model Quality of IWMV_V2 = " + evaluation.pctCorrect());
					
					// IWMV_DVLFC
					double MVL_IWMV_result12 = 0;
					for (int j = 0; j < test.getExampleSize(); j++) {
						Example MVL_IWMV_test_view1_example = MVL_IWMV_test_view1.getExampleByIndex(j);
						Example MVL_IWMV_test_view2_example = MVL_IWMV_test_view2.getExampleByIndex(j);
						double[] re_view1 = m_classifier_view1.distributionForInstance(MVL_IWMV_test_view1_example);
						double[] re_view2 = m_classifier_view2.distributionForInstance(MVL_IWMV_test_view2_example);
						double[] re_view12 = re_view1;
						for (int yy = 0; yy < re_view1.length; yy++) {
							re_view12[yy] += re_view2[yy];
						}
						if (Utils.maxIndex(re_view12) == MVL_IWMV_test_view1_example.classValue()) {
							MVL_IWMV_result12++;
						}
					}
					MVL_IWMV_result12 = MVL_IWMV_result12 / test.getExampleSize() * 100;
					classifi_acc[7] += MVL_IWMV_result12;
					System.out.println("Model Quality of IWMV_DVLFC = " + MVL_IWMV_result12);
					
					// GTIC
					Dataset GTIC_train = Dataset.copyDataset(train);
					GTIC gtic = new GTIC(dataSetArffDir);
					gtic.doInference(GTIC_train);
					reporter.stat(GTIC_train);
					inte_acc[4] += reporter.getAccuracy() *100;
					System.out.println("GTIC accuracy: " + reporter.getAccuracy() + " Roc Area: " + reporter.getAUC()
							+ " Recall: " + reporter.getRecallBinary() + " Precision: " + reporter.getPresicionBinary() + " F1:"
							+ reporter.getF1MeasureBinary());
					GTIC_train.assignIntegeratedLabel2WekaInstanceClassValue();
					m_classifier.buildClassifier(GTIC_train);
					Dataset GTIC_test = Dataset.copyDataset(test);
					evaluation = new Evaluation(GTIC_test);
					evaluation.evaluateModel(m_classifier, GTIC_test);
					classifi_acc[8] += evaluation.pctCorrect();

					// GTIC_V1
					Dataset MVL_GTIC_train_view1 = Dataset.copyDataset(train);
					DVLFC_GTIC mvl_gtic = new DVLFC_GTIC();
					mvl_gtic.doInference(MVL_GTIC_train_view1);
					reporter.stat(MVL_GTIC_train_view1);
					inte_acc[5] += reporter.getAccuracy() * 100;
					System.out.println("GTIC_V1 accuracy: " + reporter.getAccuracy() + " Roc Area: " + reporter.getAUC()
							+ " Recall: " + reporter.getRecallBinary() + " Precision: " + reporter.getPresicionBinary() + " F1:"
							+ reporter.getF1MeasureBinary());
					m_classifier_view1.buildClassifier(MVL_GTIC_train_view1);
					Dataset MVL_GTIC_test_view1 = Dataset.copyDataset(test);
					evaluation = new Evaluation(MVL_GTIC_test_view1);
					evaluation.evaluateModel(m_classifier_view1, MVL_GTIC_test_view1);
					classifi_acc[9] += evaluation.pctCorrect();
					System.out.println("Model Quality of GTIC_V1=" + evaluation.pctCorrect());

					// GTIC_V2
					Dataset MVL_GTIC_train_view2 = Dataset.copyDataset(train);
					DVLFC_GTIC mvl_GTIC2 = new DVLFC_GTIC();
					mvl_GTIC2.doInference(MVL_GTIC_train_view2);
					MVL_GTIC_train_view2 = mvl_GTIC2.generateAugmentedLabelView_Train(MVL_GTIC_train_view2);
					m_classifier_view2.buildClassifier(MVL_GTIC_train_view2);
					Dataset MVL_GTIC_test_view2 = mvl_GTIC2.generateAugmentedLabelView_Test(test,
							MVL_GTIC_train_view2.numAttributes() - 1);
					evaluation = new Evaluation(MVL_GTIC_test_view2);
					evaluation.evaluateModel(m_classifier_view2, MVL_GTIC_test_view2);
					classifi_acc[10] += evaluation.pctCorrect();
					System.out.println("Model Quality of GTIC_V2=" + evaluation.pctCorrect());
					
					// GTIC_DVLFC
					double MVL_GTIC_result12 = 0;
					for (int j = 0; j < test.getExampleSize(); j++) {

						Example MVL_GTIC_test_view1_example = MVL_GTIC_test_view1.getExampleByIndex(j);
						Example MVL_GTIC_test_view2_example = MVL_GTIC_test_view2.getExampleByIndex(j);
						double[] re_view1 = m_classifier_view1.distributionForInstance(MVL_GTIC_test_view1_example);
						double[] re_view2 = m_classifier_view2.distributionForInstance(MVL_GTIC_test_view2_example);
						double[] re_view12 = re_view1;
						for (int yy = 0; yy < re_view1.length; yy++) {
							re_view12[yy] += re_view2[yy];
						}
						if (Utils.maxIndex(re_view12) == MVL_GTIC_test_view1_example.classValue()) {
							MVL_GTIC_result12++;
						}
					}
					MVL_GTIC_result12 = MVL_GTIC_result12 / test.getExampleSize() * 100;
					classifi_acc[11] += MVL_GTIC_result12;
					System.out.println("Model Quality of GTIC_DVLFC = " + MVL_GTIC_result12);

					// MNLDP
					Dataset MNLDP_train = Dataset.copyDataset(train);
					Iteration MNLDP = new Iteration();
					MNLDP.doinference(MNLDP_train, 50);
					reporter.stat(MNLDP_train);
					inte_acc[6] += reporter.getAccuracy() *100;
					System.out.println("MNLDP accuracy: " + reporter.getAccuracy() + " Roc Area: " + reporter.getAUC()
							+ " Recall: " + reporter.getRecallBinary() + " Precision: " + reporter.getPresicionBinary() + " F1:"
							+ reporter.getF1MeasureBinary());
					MNLDP_train.assignIntegeratedLabel2WekaInstanceClassValue();
					m_classifier.buildClassifier(MNLDP_train);
					Dataset MNLDP_test = Dataset.copyDataset(test);
					evaluation = new Evaluation(MNLDP_test);
					evaluation.evaluateModel(m_classifier, MNLDP_test);
					classifi_acc[12] += evaluation.pctCorrect();
					System.out.println("MNLDP=" + evaluation.pctCorrect());

					// MNLDP_V1
					Dataset MVL_MNLDP_train_view1 = Dataset.copyDataset(train);
					DVLFC_MNLDP mvl_mnldp = new DVLFC_MNLDP();
					mvl_mnldp.doInference(MVL_MNLDP_train_view1);
					reporter.stat(MVL_MNLDP_train_view1);
					inte_acc[7] += reporter.getAccuracy() *100;
					System.out.println("MNLDP_V1 accuracy: " + reporter.getAccuracy() + " Roc Area: " + reporter.getAUC()
							+ " Recall: " + reporter.getRecallBinary() + " Precision: " + reporter.getPresicionBinary() + " F1:"
							+ reporter.getF1MeasureBinary());
					m_classifier_view1.buildClassifier(MVL_MNLDP_train_view1);
					Dataset MVL_MNLDP_test_view1 = Dataset.copyDataset(test);
					evaluation = new Evaluation(MVL_MNLDP_test_view1);
					evaluation.evaluateModel(m_classifier_view1, MVL_MNLDP_test_view1);
					classifi_acc[13] += evaluation.pctCorrect();
					System.out.println("Model Quality of MNLDP_V1 = " + evaluation.pctCorrect());

					// MNLDP_V2
					Dataset MVL_MNLDP_train_view2 = Dataset.copyDataset(train);
					DVLFC_MNLDP mvl_mnldp2 = new DVLFC_MNLDP();
					mvl_mnldp2.doInference(MVL_MNLDP_train_view2);
					MVL_MNLDP_train_view2 = mvl_mnldp2.generateAugmentedLabelView_Train(MVL_MNLDP_train_view2);
					m_classifier_view2.buildClassifier(MVL_MNLDP_train_view2);
					Dataset MVL_MNLDP_test_view2 = mvl_mnldp2.generateAugmentedLabelView_Test(test,
							MVL_MNLDP_train_view2.numAttributes() - 1);
					evaluation = new Evaluation(MVL_MNLDP_test_view2);
					evaluation.evaluateModel(m_classifier_view2, MVL_MNLDP_test_view2);
					classifi_acc[14] += evaluation.pctCorrect();
					System.out.println("Model Quality of MNLDP_V2 = " + evaluation.pctCorrect());
					
					// MNLDP_DVLFC
					double MVL_MNLDP_result12 = 0;
					for (int j = 0; j < test.getExampleSize(); j++) {
						Example MVL_MNLDP_test_view1_example = MVL_MNLDP_test_view1.getExampleByIndex(j);
						Example MVL_MNLDP_test_view2_example = MVL_MNLDP_test_view2.getExampleByIndex(j);
						double[] re_view1 = m_classifier_view1.distributionForInstance(MVL_MNLDP_test_view1_example);
						double[] re_view2 = m_classifier_view2.distributionForInstance(MVL_MNLDP_test_view2_example);
						double[] re_view12 = re_view1;
						for (int yy = 0; yy < re_view1.length; yy++) {
							re_view12[yy] += re_view2[yy];
						}
						if (Utils.maxIndex(re_view12) == MVL_MNLDP_test_view1_example.classValue()) {
							MVL_MNLDP_result12++;
						}
					}
					MVL_MNLDP_result12 = MVL_MNLDP_result12 / test.getExampleSize() * 100;
					classifi_acc[15] += MVL_MNLDP_result12;
					System.out.println("Model Quality of MNLDP_DVLFC = " + MVL_MNLDP_result12);
					
					String dataName = dataSetArddFix[data].split("/")[0];

					fw.write(dataName + String.valueOf(i) + String.valueOf(k));

					for (int index = 0; index < classifi_acc.length; index++) {
						fw.write("," + df.format(classifi_acc[index]));
						classifi_acc_all[index] += classifi_acc[index];
					}
					fw.write("\r\n");
					
					fw2.write(dataName + String.valueOf(i) + String.valueOf(k));

					for (int index = 0; index < inte_acc.length; index++) {
						fw2.write("," + df.format(inte_acc[index]));
						integra_acc_all[index] += inte_acc[index];
					}
					fw2.write("\r\n");

				}

			}
			
			fw.write("Average");
			for (int index = 0; index < classifi_acc_all.length; index++) {
				fw.write("," + df.format(classifi_acc_all[index] / num_times / num_Folds));
			}
			fw.write("\r\n");
			fw.close();
			
			fw2.write("Average");
			for (int index = 0; index < integra_acc_all.length; index++) {
				fw2.write("," + df.format(integra_acc_all[index] / num_times / num_Folds));
			}
			fw2.write("\r\n");
			fw2.close();
			
			}

	}

}
